

# import asyncio
# from client.llm_client2 import LLMClient



# async def main():
#     llm_client = LLMClient()
#     message=[
#             {"role":"user","content":"Hello, how are you?"  }
#         ]
#     async for event in llm_client.chat_completion(
#       message,
#         True
#     ):
#         print(event)

#     print('done..')

# # This runs the async function properly
# if __name__ == "__main__":
#     result = asyncio.run(main())
#     # print(f"Response: {result}")








import asyncio
from pathlib import Path
import sys
from typing import Any
from agent.agent import Agent
from agent.events import AgentEventType
from client.llm_client2 import LLMClient
import click

from config.config import Config
from config.loader import load_config
from ui.tui import TUI, get_console


console = get_console()

# class CLI:
#     def __init__(self):
#         self.agent: Agent | None = None
#         self.tui = TUI(console=console)

#     async def run_single(self,message:str)->str|None:
#          async with Agent() as agent:
#              self.agent = agent
#              return  await self._process_message(message)

#     # This function is responsible for processing the user message and getting the response from the agent and print it to the according to the type of event and message type we get from the agent
#     async def _process_message(self,message:str)->str | None:
#         if not self.agent:
#             return None
#         async for event in self.agent.run(message):
#             if event.type == AgentEventType.AGENT_START:
#                 # print(f"Agent started with message: {event.data.get('message')}")

#                 continue
#             if event.type == AgentEventType.TEXT_DELTA:
#                 content = event.data.get("content","")
#                 self.tui.stream_assistant_delta(content)
class CLI:

    def __init__(self,config: Config):
        self.agent: Agent | None = None
        self.config = config
        self.tui = TUI(config,console)

    async def run_single(self, message: str) -> None:
 
        async with Agent(config=self.config) as agent:

            self.agent = agent

            await self._process_message(message)

    # This is used to run in interactive mode {by communicating with or cli }
    async def run_interactive(self) -> str | None:
        self.tui.print_welcome(
            "AI Agent",
            lines=[
                # f"model: openrouter/free",
                f"model: {self.config.model_name}",
                # f"model: nvidia/nemotron-3-nano-30b-a3b:free",
                f"cwd: {self.config.cwd}",
                "commands: /help /config /approval /model /exit",
            ],
        )

        async with Agent(config=self.config) as agent:

            self.agent = agent
            while True: # It is infinite loop to intract in cli 
                try:
                    user_input = console.input("\n[user]>[/user] ").strip()
                    if not user_input:
                        continue
                    await self._process_message(user_input)

                except KeyboardInterrupt:
                    console.print("\n[dim]Use /exit to quit[/dim]")
                except EOFError:
                    break

        return console.print("\n[dim]Good buy![/dim]")
            
            

            

    def _get_tool_kind(self, tool_name: str) -> str | None:
        tool_kind = None
        tool = self.agent.session.tool_registry.get(tool_name)
        if not tool:
            tool_kind = None

        tool_kind = tool.kind.value

        return tool_kind

    
    async def _process_message(self, message: str) -> None:

        if not self.agent:
            return
        
        # It(assistant_streaming) is used to show assistance start horizontal line before first message coming 
        assistant_streaming = False
        final_response: str | None = None

        async for event in self.agent.run(message):
            # print(event)

            # ❌ DO NOT EXIT HERE
            if event.type == AgentEventType.AGENT_START:
                continue

            if event.type == AgentEventType.TEXT_DELTA:

                content = event.data.get("content", "")
                if not assistant_streaming:
                    self.tui.begin_assistant()
                    assistant_streaming = True
                self.tui.stream_assistant_delta(content)
            elif event.type == AgentEventType.TEXT_COMPLETE:
                final_response = event.data.get("content", "")
                if assistant_streaming:
                    self.tui.end_assistant()
                    assistant_streaming = False

            # if event.type == AgentEventType.AGENT_END:
            #     self.tui.stream_assistant_delta("\n")
            #     break

            elif event.type == AgentEventType.AGENT_ERROR:
                error = event.data.get("error", "Unknown error")
                console.print(f"\n[error]ERROR: {error}[/error]")
            elif event.type == AgentEventType.TOOL_CALL_START:
                tool_name =  event.data.get("name","unknown")
                tool_kind = None
                # tool = self.agent.tool_registry.get(tool_name)
                tool = self.agent.session.tool_registry.get(tool_name)
                print(type(self.agent.session.tool_registry))
                if not tool:
                    tool_kind = None
                
                tool_kind = tool.kind.value
                self.tui.tool_call_start(
                    event.data.get("call_id",""),
                    tool_name,
                    tool_kind,
                    event.data.get("arguments",{}),

                )
            elif event.type == AgentEventType.TOOL_CALL_COMPLETE:
                tool_name = event.data.get("name", "unknown")
                tool_kind = self._get_tool_kind(tool_name)
                self.tui.tool_call_complete(
                    event.data.get("call_id", ""),
                    tool_name,
                    tool_kind,
                    event.data.get("success", False),
                    event.data.get("output", ""),
                    event.data.get("error"),
                    event.data.get("metadata"),
                    event.data.get('diff'),
                \
                    event.data.get("truncated", False),
                    event.data.get("exit_code")
                   
                )

                
                
        return final_response 

            


@click.command()
@click.argument("prompt",required=False)
@click.option(
    "--cwd",
    "-c",
    type=click.Path(exists=True, file_okay=False, path_type=Path),
    help="Current working directory",
)
def main(prompt:str|None,cwd:Path|None):
    try:
        config = load_config(cwd=cwd)
    except Exception as e:
        console.print(f"[error]Configuration Error: {e}[/error]")

    errors = config.validate()

    if errors:
        for error in errors:
            console.print(f"[error]{error}[/error]")

        sys.exit(1)
    cli = CLI(config=config)


    # messages=[
    #         {"role":"user","content":prompt}
    #     ]
    if prompt:
        result = asyncio.run(cli.run_single(prompt))
        if result is None:
                sys.exit(1)
    else:
         asyncio.run(cli.run_interactive());
# This runs the async function properly
main()
    # print(f"Response: {result}")





# FOR WINDOWS [it diff for mac/linux] {system level config.tomel file where required config defined}
# "C:\Users\DEEPAK YADAV\AppData\Local\claude-code-type-agent\claude-code-type-agent\config.toml"



#  HOW TO RUN 
# set API_KEY=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
# set BASE_URL => set BASE_URL=https://openrouter.ai/api/v1  {iF NEED OTHER WISE IT TAKE IT FROM TOMAL FILE SYSTEM OR PROJECT LEVEL}





    # 06:11:00 timing
    # 07:41:00 max_turn used ehich define in session
    # 09:05:29 